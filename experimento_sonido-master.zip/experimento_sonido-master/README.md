# sonico
Repositorio de datos y codigos para el proyecto de WTP y sonido
